export class User {
    exists: boolean;
    score: number;
}