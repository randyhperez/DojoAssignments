export class User {
    fName: string;
    lName: string;
    email: string;
    password: string;
    passwordConf: string;
    street: string;
    unit: string;
    city: string;
    state: string;
    lucky: boolean;
}